from distutils.core import setup

setup(
    name='PythonLists',
    version='1.0.0',
    py_modules=['PythonLists'],
    author='Aitor',
    author_email='aitor.calero@gmail.com',
    url='http://www.uncafelitoalasonce.com',
    description='A simple example of HeadFirst Python Book',
)